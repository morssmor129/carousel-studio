# Zanim ruszy parkiet

## Slajd 1

Zanim ruszy
parkiet

Trzy decyzje do omówienia z DJ-em.

Tekst alternatywny: Konsola i laptop DJ-a w ciepłym i niebieskim świetle. Tytuł Zanim ruszy parkiet.

## Slajd 2

Wybierz utwór
na wejście

Zaznacz fragment, od którego DJ ma zacząć.

Tekst alternatywny: Para idzie pomiędzy klaszczącymi gośćmi. Obok zdjęcia wskazówka, by wybrać utwór i zaznaczyć właściwy fragment.

## Slajd 3

Daj DJ-owi swobodę

Powiedz, kiedy ma trzymać się listy, a kiedy może podążyć za gośćmi.

Tekst alternatywny: Uśmiechnięci goście wokół pary. Pod zdjęciem wskazówka o ustaleniu, kiedy DJ może reagować na to, co dzieje się na sali.

## Slajd 4

Ustal, kiedy
rusza parkiet

Wskaż DJ-owi sygnał do pierwszego bloku tanecznego.

Tekst alternatywny: Lewa część plenerowej panoramy. Widać klaszczących gości i girlandy. Zdjęcie przechodzi na następny slajd.

## Slajd 5

Zapisz te trzy ustalenia

Utwór na wejście, swoboda DJ-a i sygnał do startu parkietu.

Tekst alternatywny: Prawa część tej samej panoramy pokazuje całującą się parę i gości. Na dole lista trzech ustaleń do zapisania.

## Zdjęcia użyte w demonstracji

- Chinarianphotographer · Pexels #5789237 · https://images.pexels.com/photos/5789237/pexels-photo-5789237.jpeg
- Samet Tecimen · Pexels #38930321 · https://images.pexels.com/photos/38930321/pexels-photo-38930321.jpeg
- kayaartsss · Pexels #14788184 · https://images.pexels.com/photos/14788184/pexels-photo-14788184.jpeg
- Photography Maghradze PH · Pexels #29237413 · https://images.pexels.com/photos/29237413/pexels-photo-29237413.jpeg

Licencja Pexels: https://www.pexels.com/license/
