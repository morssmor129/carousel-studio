# Najpierw oklaski

## Slajd 1

Najpierw oklaski.

Przesuń, żeby zobaczyć, dla kogo biją brawo.

Tekst alternatywny: Lewa połowa szerokiego zdjęcia. Goście klaszczą pod girlandami podczas wesela w plenerze.

## Slajd 2

Potem ta chwila.

Zapisz pomysł na jeden kadr rozłożony na dwa slajdy.

Tekst alternatywny: Prawa połowa tego samego zdjęcia. Para całuje się pod girlandami pośród klaszczących gości.

## Zdjęcia

- Photography Maghradze PH · Pexels #29237413 · https://images.pexels.com/photos/29237413/pexels-photo-29237413.jpeg

Licencja Pexels: https://www.pexels.com/license/
