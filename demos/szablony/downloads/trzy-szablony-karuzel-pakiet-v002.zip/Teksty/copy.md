# Trzy szablony. Jeden temat.

## Slajd 1

Trzy szablony.
Jeden temat.

Kącik do pracy w trzech wersjach. Przesuń, żeby porównać układy.

Tekst alternatywny: Ciemnozielona okładka przedstawia trzy układy: tekst, zdjęcie oraz linię łączącą slajdy.

## Slajd 2

Sprawdź, skąd pada światło

Usiądź przy biurku i sprawdź, czy okno odbija się w ekranie. Przesuń ekran, aż odbicie zniknie.

Tekst alternatywny: Jasny slajd edukacyjny z poradą, jak sprawdzić i ograniczyć odbicie okna w ekranie.

## Slajd 3

Pokaż kącik z góry

Jeden kadr pokazuje, co jest pod ręką: komputer, książka i roślina.

Tekst alternatywny: Zdjęcie z góry przedstawia laptop, książkę i roślinę na drewnianym tle. Pod zdjęciem znajduje się krótki podpis.

## Slajd 4

Zacznij przy oknie

Zobacz, skąd wpada światło. Przesuń dalej i śledź linię.

Tekst alternatywny: Pierwsza część panoramy. Dwie terakotowe linie biegną do prawej krawędzi slajdu.

## Slajd 5

Przejdź do biurka

Ta sama linia łączy oba kafelki. Tak możesz pokazać trasę, proces lub szeroki kadr.

Tekst alternatywny: Druga część panoramy. Dwie linie wchodzą z lewej strony na tej samej wysokości, na której wychodzą z poprzedniego slajdu.

## Slajd 6

Który układ wybierzesz?

Edukacyjny • tłumaczy krok.
Zdjęciowy • pokazuje detal.
Panorama • łączy slajdy w całość.

Zapisz przed następną karuzelą.

Tekst alternatywny: Podsumowanie. Układ edukacyjny wyjaśnia krok, zdjęciowy pokazuje detal, a panorama łączy slajdy. Na końcu prośba o zapisanie karuzeli.

## Źródło zdjęcia ze slajdu 3

[Pixabay / Pexels](https://www.pexels.com/photo/books-laptop-and-smartphone-on-table-265678/) · [CC0](https://www.pexels.com/creative-commons-images/)
